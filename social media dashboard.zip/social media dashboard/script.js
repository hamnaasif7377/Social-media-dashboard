document.addEventListener('DOMContentLoaded', () => {
    // Sample data
    const data = {
        user: {
            name: 'Hamna Asif',
            profilePicture: 'profile.png',
            followers: 1200,
            engagementRate: 4.5,
            activityTimeline: [
                { date: '2023-01-01', activity: 'Posted a photo' },
                { date: '2023-01-02', activity: 'Gained 100 followers' }
            ]
        },
        metrics: {
            followerGrowth: [100, 150, 200, 250, 300],
            engagementRates: [4.2, 4.3, 4.4, 4.5, 4.6]
        }
    };

    updateDashboard(data);

    function updateDashboard(data) {
        document.querySelector('.profile-picture').src = data.user.profilePicture;
        document.querySelector('.user-name').textContent = data.user.name;
        document.getElementById('total-followers').textContent = data.user.followers;

        const activityTimeline = document.getElementById('activityTimeline');
        activityTimeline.innerHTML = '';
        data.user.activityTimeline.forEach(activity => {
            const li = document.createElement('li');
            li.textContent = `${activity.date}: ${activity.activity}`;
            activityTimeline.appendChild(li);
        });

        const ctxFollowerGrowth = document.getElementById('followerGrowthChart').getContext('2d');
        new Chart(ctxFollowerGrowth, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
                datasets: [{
                    label: 'Follower Growth',
                    data: data.metrics.followerGrowth,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1,
                    fill: false
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const ctxEngagementRate = document.getElementById('engagementRateChart').getContext('2d');
        new Chart(ctxEngagementRate, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
                datasets: [{
                    label: 'Engagement Rate',
                    data: data.metrics.engagementRates,
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
});
